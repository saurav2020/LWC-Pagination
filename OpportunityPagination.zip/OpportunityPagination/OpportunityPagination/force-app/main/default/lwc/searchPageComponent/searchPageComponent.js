import { LightningElement, wire, track } from "lwc";
import getOpportunityList from "@salesforce/apex/OppClass.getOpportunityList";
import searchOpportunity from "@salesforce/apex/OppClass.searchOpportunity";
import sending from "@salesforce/apex/OppClass.sending";
import { ShowToastEvent } from "lightning/platformShowToastEvent";
import { NavigationMixin } from 'lightning/navigation';
import getOpportunities from '@salesforce/apex/OppClass.getOpportunities';

const actions = [{ label: "Send", name: "Send" }];

const columns = [
{
label: "Name",
fieldName: "nameurl",
type: "url",
typeAttributes: {
    label: { fieldName: "Name" },
    target: "_blank"
}
},
{
label: "Account Name",
fieldName: "accounturl",
type: "url",
typeAttributes: {
    label: { fieldName: "AccountName" },
    target: "_blank"
}
},
{
label: "Amount",
fieldName: "Amount",
type: "currency",
typeAttributes: { currencyCode: "INR" },
cellAttributes: { alignment: "left" }
},
{ label: "Stage", fieldName: "StageName" },
{ label: "Type", fieldName: "Type" },
{
label: "Action",
type: "button",
initialWidth: 120,
typeAttributes: {
    label: "Send Data",
    name: "sendData",
    title: "Send",
    variant: "success"
}
},
{
    label: "Details",
type: "button",
initialWidth: 120,
typeAttributes: {
    label: "View Data",
    name: "viewData",
    title: "Details",
    variant: "brand"}

/*type: "button-icon",
initialWidth: 50,
typeAttributes: {
    label: "View Data",
    name: "viewData",
    iconName: 'action:info',
    title: "View",
    variant: "border-filled"
}*/
},

];

export default class SearchPageComponent extends LightningElement {
// columns = columns;
@track bModal = false;
@track record = {};
//   @track delModal = false;
hasPrev = false;
hasNext = true;
columns = columns;
variantValue = "Brand";
data;
pageNumber;
copyofdata;
recordsPerPage;
value = 0;
curr = 0;
 @track recordId;
 @track showSuccess=false;
@track showpopup=false;
@wire(getOpportunityList) Account(result) {
if (result.data) {
    let values = [];
    result.data.forEach((i) => {
    let value = {};
    value.Id = i.Id;
    value.Name = i.Name;
    value.nameurl = `/${i.Id}`;
    value.StageName = i.StageName;
    value.Type = i.Type;
    value.Amount = i.Amount;
    value.AccountName = i.Account.Name;
    value.accounturl = `/${i.Account.Id}`;
    value.Integration_Status__c = i.Integration_Status__c;
    value.Integration_Comments__c = i.Integration_Comments__c;
    values.push(value);
    });
    this.data = values;
    this.copyofdata = values;
    if(this.data="")
    alert('enter valid text');
    console.log(this.data);
} else if (result.error) {
    this.data = undefined;
    this.error = result.error;
}
}

getrowAction(event) {
if (event.detail.action.name == "sendData") {
    const actionName = event.detail.action.name;
    const row = event.detail.row;
    const id = row.Id;
    this.recordId=id;
    console.log(id);
    try {
    sending({ selectedRec: id })
        .then((data) => {
       const evt = new ShowToastEvent({
            title: "Fields Updated Successfully",
            message: data,
            variant: "success",
            mode: "dismissable"
        });
        this.dispatchEvent(evt);
        this.navigateToViewAccountPage();       
        })        
        .catch((err) => {
        const evt = new ShowToastEvent({
        title: "Fields Not Updated",
        message: data,
        variant: "base",
        mode: "dismissable"
        });
        this.dispatchEvent(evt);
        this.navigateToViewAccountPage();})

    } catch (error) {
    console.log(error);
    }
    
} else if (event.detail.action.name == "viewData") {
    this.record = event.detail.row;
    this.openModal();

}

}


navigateToViewAccountPage() {
    console.log('entered134654');
    /*this[NavigationMixin.Navigate]({
        type: 'standard__recordPage',
        attributes: {
            recordId: this.recordId,
            objectApiName: 'namespace__Opportunity',
            actionName: 'view'
        },
    });*/

    this.showSuccess=true;
    console.log(this.recordId);
}
/*OpportunityPage()
{ console.log('hello qorld');
    this[NavigationMixin.Navigate]({
        type: 'standard__recordPage',
        attributes: {
            recordId: this.recordId,
            objectApiName: 'namespace__Opportunity',
            actionName: 'view'
        },
    });
}*/

//Functions to open and close the view record modal.
openModal() {

this.bModal = true;
}

closeModal() {
this.bModal = false;
this.showSuccess=false;
this.showpopup=false;
}


handleKeyWordChange(event) {
this.pageNumber = 1;
const keyword = event.target.value;
keyword.toUpperCase();

console.log(keyword);

if (keyword != "") {
    searchOpportunity({ keyword }).then((result) => {
    let values = [];
    result.forEach((i) => {
        let value = {};
        value.Id = i.Id;
        value.Name = i.Name;
        value.nameurl = `/${i.Id}`;
        value.StageName = i.StageName;
        value.Type = i.Type;
        value.Amount = i.Amount;
        value.AccountName = i.Account.Name;
        value.accounturl = `/${i.Account.Id}`;
        values.push(value);
    });
    if (this.value < this.copyofdata.length) {
        this.data = values.slice(0, this.value);
        // console.log(result);
    } else {
        this.data = values;
    }
    });
} else {
    if (this.value < this.copyofdata.length) {
    this.data = this.copyofdata.slice(0, this.value);
    } else {
    this.data = null;
    }
}
if (keyword == "") {
    //alert("Please Enter Some Text");
    this.refresh();
}
this.value = 5;
console.log(this.value);
if (this.value < this.copyofdata.length) {
    this.data = this.copyofdata.slice(0, this.value);
    console.log(this.copyofdata.slice(0, this.value));
    this.curr = this.value;
    console.log(this.curr);
} else {
    this.data = null;
}
}

onNext() {
if (
    this.value < this.copyofdata.length &&
    this.curr < this.copyofdata.length
) {
    this.data = this.copyofdata.slice(this.curr, +this.curr + +this.value);
    this.curr = +this.curr + +this.value;
    if (this.curr >= this.copyofdata.length) {
    this.hasNext = false;
    this.hasPrev = true;
    }
    this.hasPrev = true;
} else {
    this.hasNext = false;
    this.hasPrev = true;
}
}
onPrev() {
if (this.value >= 0 && this.curr >= 0) {
    this.data = this.copyofdata.slice(+this.curr - +this.value, this.curr);
    this.curr = +this.curr - +this.value;
    if (this.curr <= 0) {
    this.hasNext = true;
    this.hasPrev = false;
    }
    this.hasNext = true;
} else {
    this.hasNext = true;
    this.hasPrev = false;
}
}
 refresh()
 {
     window.location.reload();
 }

 @track chartConfiguration;

 @wire(getOpportunities, {})
 getOpportunities({error, data}) {
  if (error) {
   this.error = error;
   console.log('error => ' + JSON.stringify(error));
   this.chartConfiguration = undefined;
  } else if (data) {
   let chartData = [];
   let chartLabels = [];
   data.forEach(opp => {
    chartData.push(opp.Amount);
    chartLabels.push(opp.Name);
   });

   this.chartConfiguration = {
    type: 'bar',
    data: {
     labels: chartLabels,
     datasets: [
      {
       label: 'Amount',
       barPercentage: 0.5,
       barThickness: 6,
       maxBarThickness: 8,
       minBarLength: 2,
                            backgroundColor: "green",
       data: chartData,
      },
     ],
    },
    options: {
    },
   };
   console.log('data => ', data);
   this.error = undefined;
  }
 }
 showChart()
 {
     this.showpopup=true;
 }

}