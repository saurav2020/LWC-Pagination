import { LightningElement, wire, track } from "lwc";  
 import getOpportunities from "@salesforce/apex/OpportunityController.fetchOpportunityList";  
 const COLS = [  
  {  
   label: "Name",  
   fieldName: "recordLink",  
   type: "url",  
   typeAttributes: { label: { fieldName: "Name" }, tooltip:"Name", target: "_blank" }  
  },  
  {  
    label: "Account",  
    fieldName: "recordLink1",  
    type: "url",  
    typeAttributes: { label: { fieldName: "AccountId" }, tooltip:"Account", target: "_blank" }  
   }, 
  { label: "Stage", fieldName: "StageName", type: "text" },  
  { label: "Amount", fieldName: "Amount", type: "currency" },
  {  
    label: "Action",  
    type: "button",  
    typeAttributes: { label: "Send Data", tooltip:"Send to third party", name:"sendData",variant:"border-filled"}  
   }
 ];  
 export default class OpportunitySearch extends LightningElement {  
  cols = COLS;  
  error;  
  @track oppList = []; 
 @track record={};
   @track inputValue; 
   @track showTable=false;
  handleClick(event)
  {
    var inp=this.template.querySelector("lightning-input");
    this.inputValue=inp.value;
    console.log(this.inputValue);
    console.log('entered1');
  }
  @wire(getOpportunities,{searchKey:'$inputValue'})
  getOppList({ error, data }) {  
    console.log('entered 2');
    this.showTable=true;
   if (data) {  
    var tempOppList = [];  
    for (var i = 0; i < data.length; i++) {  
     let tempRecord = Object.assign({}, data[i]); //cloning object  
     tempRecord.recordLink = "/" + tempRecord.Id; 
     console.log(tempRecord);
     tempRecord.recordLink1 = "/" + tempRecord.AccountId;   
     tempOppList.push(tempRecord);  
    }  
    this.oppList = tempOppList;  
    this.error = undefined;  
   } else if (error) {  
    this.error = error;  
    this.oppList = undefined;  
   }  
  }  
  handleRowAction(event)
  {
    const row=event.detail.row;
    this.record=row;
    //const id=row.Id;
    console.log(this.record);
  }
 }